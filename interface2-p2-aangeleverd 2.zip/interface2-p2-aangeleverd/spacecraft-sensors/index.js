class SpacecraftSensors {
    static getTemperature() {
        return Math.floor(Math.random() * (100 - (-50))) + (-50); // Temperature between -50 and 100
    }

    static getHumidity() {
        return Math.floor(Math.random() * 100); // Humidity between 0 and 100
    }

    static getRandomResource() {
        const resources = [
            "Iron Ore",
            "Gold",
            "Silver",
            "Platinum",
            "Helium-3",
            "Water Ice"
        ];
        return resources[Math.floor(Math.random() * resources.length)];
    }
}

module.exports = SpacecraftSensors; 