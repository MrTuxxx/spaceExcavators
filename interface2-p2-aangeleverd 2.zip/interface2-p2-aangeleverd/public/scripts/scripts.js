// Fetch the current status of the spacecraft
async function fetchStatus() {
    try {
        const response = await fetch('/status', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const status = await response.json();
        if (status.power === "OFF") {
            document.getElementById('power').classList.remove('on');
            document.getElementById('power').classList.add('off');
        } else {
            document.getElementById('power').classList.remove('off');
            document.getElementById('power').classList.add('on');
        }
        document.getElementById('power').getElementsByTagName("span")[0].textContent = `${status.power}`;
        document.getElementById('speed').textContent = `Speed: ${status.speed}`;
        document.getElementById('fuel').textContent = `Fuel: ${status.fuel}`;
    } catch (error) {
        console.error('Error fetching status:', error);
    }
}

// Update the speed of the spacecraft
async function updateSpeed(newSpeed) {
    try {
        const response = await fetch('/action', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: newSpeed > 0 ? 'MOVE_FORWARD' : 'MOVE_BACKWARD'
            })
        });
        
        const result = await response.json();
        if (result.success) {
            updateStatus();
        }
    } catch (error) {
        console.error('Error updating speed:', error);
    }
}

// Refuel the spacecraft to desired amount
async function refuel(amount) {
    try {
        const response = await fetch('/action', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'REFUEL',
                details: { amount: amount }
            })
        });
        
        const result = await response.json();
        if (result.success) {
            updateStatus();
        }
    } catch (error) {
        console.error('Error refueling:', error);
    }
}

// Set the power state of the spacecraft
async function setPower(powerState) {
    try {
        const response = await fetch('/action', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'SLEEP_MODE'
            })
        });
        
        const result = await response.json();
        if (result.success) {
            updateStatus();
        }
    } catch (error) {
        console.error('Error changing power state:', error);
    }
}

// Voeg deze functie toe aan je bestaande code
function updateRoverAnimation(speed) {
    const container = document.querySelector('.rover-image');
    if (speed !== 0) {
        container.classList.add('moving');
    } else {
        container.classList.remove('moving');
    }
}

// Status ophalen en weergeven
async function updateStatus() {
    try {
        const response = await fetch('/status', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        // Update alle status elementen met de nieuwe data
        document.getElementById('battery').textContent = `${data.batteryPercentage}%`;
        document.getElementById('sensors').textContent = data.activeSensors.join(', ') || 'None';
        document.getElementById('resources').textContent = data.discoveredResources.join(', ') || 'None';
        document.getElementById('power').textContent = data.power;
        document.getElementById('speed').textContent = `${data.speed} km/h`;
        document.getElementById('fuel').textContent = `${data.fuel}%`;

        // Update power status classes
        const powerElement = document.getElementById('power');
        if (data.power === "OFF") {
            powerElement.classList.remove('on');
            powerElement.classList.add('off');
        } else {
            powerElement.classList.remove('off');
            powerElement.classList.add('on');
        }
    } catch (error) {
        console.error('Error fetching status:', error);
    }
}

// Actie formulier afhandeling
document.getElementById('actionForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const action = document.getElementById('actionSelect').value;
    const details = {
        priority: document.getElementById('prioritySelect').value,
        executionTime: document.getElementById('executionTime').value,
        notes: document.getElementById('notes').value
    };
    
    // Specifieke details per actie
    switch(action) {
        case 'TOGGLE_SENSOR':
            details.sensor = document.getElementById('sensorSelect').value;
            break;
        case 'SET_SPEED':
            details.speed = parseInt(document.getElementById('speedInput').value);
            break;
        case 'REFUEL':
            details.amount = parseInt(document.getElementById('fuelInput').value);
            break;
    }
    
    try {
        const response = await fetch('/action', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ action, details })
        });
        
        const result = await response.json();
        if (result.success) {
            updateStatus();
            // Reset form
            document.getElementById('notes').value = '';
            document.getElementById('executionTime').value = '';
        }
    } catch (error) {
        console.error('Error executing action:', error);
    }
});

// Toon/verberg relevante details op basis van geselecteerde actie
document.getElementById('actionSelect').addEventListener('change', (e) => {
    const action = e.target.value;
    
    // Verberg alle detail secties eerst
    document.getElementById('sensorDetails').style.display = 'none';
    document.getElementById('speedDetails').style.display = 'none';
    document.getElementById('fuelDetails').style.display = 'none';
    
    // Toon relevante sectie
    switch(action) {
        case 'TOGGLE_SENSOR':
            document.getElementById('sensorDetails').style.display = 'block';
            break;
        case 'SET_SPEED':
            document.getElementById('speedDetails').style.display = 'block';
            break;
        case 'REFUEL':
            document.getElementById('fuelDetails').style.display = 'block';
            break;
    }
});

// Start met één status update en herhaal elke 4 seconden
updateStatus();  // Initiële update
setInterval(updateStatus, 4000);  // Periodieke updates