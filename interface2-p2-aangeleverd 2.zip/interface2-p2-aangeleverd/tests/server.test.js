const request = require('supertest');
const app = require('../server');  // We need to export app from server.js

describe('Spacecraft Server', () => {
    describe('GET /status', () => {
        test('should return spacecraft status', async () => {
            const response = await request(app).get('/status');
            expect(response.statusCode).toBe(200);
            expect(response.body).toHaveProperty('batteryPercentage');
            expect(response.body).toHaveProperty('activeSensors');
            expect(response.body).toHaveProperty('power');
        });
    });

    describe('GET /sensor-data', () => {
        test('should return sensor data when power is ON', async () => {
            const response = await request(app).get('/sensor-data');
            expect(response.statusCode).toBe(200);
            expect(response.body).toHaveProperty('temperature');
            expect(response.body).toHaveProperty('humidity');
        });
    });

    describe('POST /action', () => {
        test('should handle MOVE_FORWARD action', async () => {
            const response = await request(app)
                .post('/action')
                .send({ action: 'MOVE_FORWARD' });
            
            expect(response.statusCode).toBe(200);
            expect(response.body.success).toBe(true);
            expect(response.body.newStatus.speed).toBe(10);
        });

        test('should handle MOVE_BACKWARD action', async () => {
            const response = await request(app)
                .post('/action')
                .send({ action: 'MOVE_BACKWARD' });
            
            expect(response.statusCode).toBe(200);
            expect(response.body.success).toBe(true);
            expect(response.body.newStatus.speed).toBe(-10);
        });

        test('should handle TOGGLE_SENSOR action', async () => {
            const response = await request(app)
                .post('/action')
                .send({ 
                    action: 'TOGGLE_SENSOR',
                    details: { sensor: 'Temperature' }
                });
            
            expect(response.statusCode).toBe(200);
            expect(response.body.success).toBe(true);
        });

        test('should handle invalid action', async () => {
            const response = await request(app)
                .post('/action')
                .send({ action: 'INVALID_ACTION' });
            
            expect(response.statusCode).toBe(400);
            expect(response.body).toHaveProperty('error');
        });

        test('should prevent movement with insufficient fuel', async () => {
            // First set fuel to low level
            app.spacecraftStatus.fuel = 2;

            const response = await request(app)
                .post('/action')
                .send({ action: 'MOVE_FORWARD' });
            
            expect(response.statusCode).toBe(400);
            expect(response.body.error).toBe('Resource Error');
        });
    });

    describe('Error Handling', () => {
        test('should handle validation errors', async () => {
            app.spacecraftStatus.batteryPercentage = 150; // Invalid value

            const response = await request(app).get('/status');
            
            expect(response.statusCode).toBe(400);
            expect(response.body.error).toBe('Validation Error');
        });

        test('should handle power errors', async () => {
            app.spacecraftStatus.power = 'OFF';

            const response = await request(app).get('/sensor-data');
            
            expect(response.statusCode).toBe(503);
            expect(response.body.error).toBe('Power System Error');
        });
    });
}); 