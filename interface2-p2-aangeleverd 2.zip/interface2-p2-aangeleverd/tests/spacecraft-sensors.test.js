const SpacecraftSensors = require('../spacecraft-sensors');

describe('SpacecraftSensors', () => {
    describe('getTemperature', () => {
        test('should return temperature between -50 and 100', () => {
            const temp = SpacecraftSensors.getTemperature();
            expect(temp).toBeGreaterThanOrEqual(-50);
            expect(temp).toBeLessThanOrEqual(100);
        });
    });

    describe('getHumidity', () => {
        test('should return humidity between 0 and 100', () => {
            const humidity = SpacecraftSensors.getHumidity();
            expect(humidity).toBeGreaterThanOrEqual(0);
            expect(humidity).toBeLessThanOrEqual(100);
        });
    });

    describe('getRandomResource', () => {
        test('should return a valid resource', () => {
            const validResources = [
                "Iron Ore",
                "Gold",
                "Silver",
                "Platinum",
                "Helium-3",
                "Water Ice"
            ];
            const resource = SpacecraftSensors.getRandomResource();
            expect(validResources).toContain(resource);
        });
    });
}); 