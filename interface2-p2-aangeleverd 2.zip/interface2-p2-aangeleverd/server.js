/**
 * Spacecraft Control Server
 * Handles all spacecraft operations and sensor management
 */

// Required packages
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
// Je importeerde vanuit de code, niet de npm package die je gemaakt hebt.
const SpacecraftSensors = require('interface2-p2-testproject');
const cors = require('cors');

// Server configuration
const app = express();
const PORT = 3000;

// Error types
const ErrorTypes = {
    VALIDATION_ERROR: 'VALIDATION_ERROR',
    SENSOR_ERROR: 'SENSOR_ERROR',
    POWER_ERROR: 'POWER_ERROR',
    RESOURCE_ERROR: 'RESOURCE_ERROR',
    SYSTEM_ERROR: 'SYSTEM_ERROR'
};

// Custom error handler middleware
const errorHandler = (err, req, res, next) => {
    console.error(`Error occurred at ${new Date().toISOString()}:`, err);

    switch (err.type) {
        case ErrorTypes.VALIDATION_ERROR:
            res.status(400).json({
                error: 'Validation Error',
                message: err.message,
                details: err.details
            });
            break;
        case ErrorTypes.SENSOR_ERROR:
            res.status(503).json({
                error: 'Sensor Malfunction',
                message: err.message,
                affectedSensor: err.sensor
            });
            break;
        case ErrorTypes.POWER_ERROR:
            res.status(503).json({
                error: 'Power System Error',
                message: err.message,
                currentPower: spacecraftStatus.power
            });
            break;
        case ErrorTypes.RESOURCE_ERROR:
            res.status(400).json({
                error: 'Resource Error',
                message: err.message,
                currentFuel: spacecraftStatus.fuel,
                currentBattery: spacecraftStatus.batteryPercentage
            });
            break;
        default:
            res.status(500).json({
                error: 'Internal Server Error',
                message: 'An unexpected error occurred'
            });
    }
};

// Spacecraft status object
let spacecraftStatus = {
    batteryPercentage: 85,
    activeSensors: ["Temperature", "Camera"],
    discoveredResources: ["Iron Ore"],
    power: "ON",
    speed: 0,
    fuel: 100,
    sensorData: {
        temperature: 20,
        humidity: 45,
        radiation: 0,
        pressure: 100
    }
};

// 1. Eerst de essentiële middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 2. Static files middleware
app.use(express.static(path.join(__dirname, 'public')));

// Logging middleware
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

// 3. API Routes
app.get('/status', (req, res) => {
    const status = {
        ...spacecraftStatus,
        batteryPercentage: Math.max(0, Math.min(100, spacecraftStatus.batteryPercentage)),
        fuel: Math.max(0, Math.min(100, spacecraftStatus.fuel))
    };
    res.json(status);
});

app.get('/sensor-data', (req, res) => {
    if (spacecraftStatus.power === "ON") {
        if (spacecraftStatus.activeSensors.includes("Temperature")) {
            spacecraftStatus.sensorData.temperature = SpacecraftSensors.getTemperature();
        }
        if (spacecraftStatus.activeSensors.includes("Humidity")) {
            spacecraftStatus.sensorData.humidity = SpacecraftSensors.getHumidity();
        }
    }
    res.json(spacecraftStatus.sensorData);
});

app.post('/action', (req, res) => {
    const { action, details } = req.body;
    
    switch(action) {
        case 'MOVE_FORWARD':
            spacecraftStatus.fuel -= 5;
            spacecraftStatus.speed = 10;
            break;
        case 'MOVE_BACKWARD':
            spacecraftStatus.fuel -= 5;
            spacecraftStatus.speed = -10;
            break;
        case 'TOGGLE_SENSOR':
            const sensor = details.sensor;
            if (spacecraftStatus.activeSensors.includes(sensor)) {
                spacecraftStatus.activeSensors = spacecraftStatus.activeSensors.filter(s => s !== sensor);
                spacecraftStatus.batteryPercentage += 5;
                if (sensor === "Temperature") {
                    spacecraftStatus.sensorData.temperature = null;
                } else if (sensor === "Humidity") {
                    spacecraftStatus.sensorData.humidity = null;
                }
            } else {
                spacecraftStatus.activeSensors.push(sensor);
                spacecraftStatus.batteryPercentage -= 5;
            }
            break;
        case 'SLEEP_MODE':
            spacecraftStatus.power = spacecraftStatus.power === "ON" ? "OFF" : "ON";
            if (spacecraftStatus.power === "OFF") {
                spacecraftStatus.speed = 0;
                spacecraftStatus.activeSensors = [];
            }
            break;
        case 'REFUEL':
            const amount = details?.amount || 100;
            spacecraftStatus.fuel = Math.min(100, spacecraftStatus.fuel + amount);
            break;
        case 'SET_SPEED':
            const newSpeed = parseInt(details?.speed) || 0;
            spacecraftStatus.speed = Math.max(-20, Math.min(20, newSpeed));
            spacecraftStatus.fuel -= Math.abs(newSpeed) * 0.1;
            break;
        default:
            return res.status(400).json({ error: 'Invalid action' });
    }
    
    spacecraftStatus.fuel = Math.max(0, spacecraftStatus.fuel);
    
    res.json({ 
        success: true, 
        newStatus: spacecraftStatus 
    });
});

// 4. Page Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

app.get('/contact', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'contact.html'));
});

// 5. Als allerlaatste: 404 handler
app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});

// Error logging
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal Server Error' });
});

// Apply error handler middleware
app.use(errorHandler);

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://127.0.0.1:${PORT}`);
});

// Export for testing
module.exports = app;
